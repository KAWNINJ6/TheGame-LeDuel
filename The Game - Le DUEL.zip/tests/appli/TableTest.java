package appli;

import static org.junit.jupiter.api.Assertions.*;

class TableTest {

}