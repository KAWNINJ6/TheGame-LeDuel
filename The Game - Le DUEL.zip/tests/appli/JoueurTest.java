package appli;

import org.junit.jupiter.api.Test;

import java.awt.geom.NoninvertibleTransformException;

import static org.junit.jupiter.api.Assertions.*;

class JoueurTest {

   /* @Test
    public void poseCartePileAsc(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void verifposeCartePileAsc(){

    }
    @Test
    public void poseCartePileDescAdv(){

    }
    @Test
    public void verifPoseCartePileDescAdv(){

    }
    @Test
    public void aCetteCarteEnMain(){

    }
    @Test
    public void nbDeCarteEnMain(){

    }*/
}