package appli;

import org.junit.jupiter.api.Test;

import java.awt.geom.NoninvertibleTransformException;

import static org.junit.jupiter.api.Assertions.*;

class JoueurTest {

   /*
    @Test
    public void poseCartePileAsc(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;

        Integer a1 = 6;
        n1.poseCartePileAsc(a1)

        assertEquals(
    }
    @Test
    public void poseCartePileAsc(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void verifPoseCartePileAsc(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void poseCartePileDesc(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void verifPoseCartePileDesc(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void poseCartePileAscAdv(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void verifPoseCartePileAscAdv(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void poseCartePileDescAdv(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void verifPoseCartePileDescAdv(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void aCetteCarteEnMain(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void aCetteCarteEnOioche(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void nbDeCarteEnMain(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void remplirMainComplet(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }
    @Test
    public void remplirMain(){
        Cartes c1 = new Cartes();
        Base b1 = new Base(this.pioche);
        Main m1 = new Main(this.pioche);
        NomJoueur n1;
        int nbJoueurs = 0;


    }

    */
}