package appli;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CartesTest {

    @Test
    public void CreationCartes(){ // Test que permet de creer un packet des cartes et regardes combient de cartes sont dans le packet
        Cartes c1 = new Cartes();
        assertEquals(60,c1.getNbCarte());
    }

    @Test
    public void piocher(){          // Test que permet de retirer une carte de le packet et de la metre dans la main et regardes combient de cartes sont dans le packet
        Cartes c1 = new Cartes();
        c1.piocherCarte();
        assertEquals(59,c1.getNbCarte());
    }
    @Test
    public void piocherPrem(){      // Test que permet la premier carte de le packet (1)
        Cartes c1 = new Cartes();
        assertEquals(1, c1.piocherPremCarte());
    }
    @Test
    public void piocherDern(){      // Test que permet la dernier carte de le packet (60)
        Cartes c1 = new Cartes();
        assertEquals(60,c1.piocherDernCarte());
    }
    @Test
    public void NbCarte(){          // Test que permet de savoir combien de carte sont dans le packets en retirent quelques unes
        Cartes c1 = new Cartes();
        assertEquals(60,c1.getNbCarte());
        c1.piocherCarte();
        assertEquals(59,c1.getNbCarte());

    }
}