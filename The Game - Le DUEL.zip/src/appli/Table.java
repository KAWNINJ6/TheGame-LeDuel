package appli;

import java.util.ArrayList;
import java.util.Scanner;

public class Table {

    private final Joueur j1 = new Joueur();
    private final Joueur j2 = new Joueur();

    private ArrayList<String> coutJoué = new ArrayList<>();
    private ArrayList<Integer> carteJoué = new ArrayList<>();

    public void lectureEntrerJ1()
    {
        Scanner sc = new Scanner(System.in);
        String s;
        int nbCarte = this.j1.nbDeCarteEnMain();

        System.out.print("> ");
        s = sc.nextLine();
        décompose(s, j1, j2);
        if (!verifSyntaxique(j1,nbCarte, j2)){
            carteJoué.clear();
            coutJoué.clear();
            while (!verifSyntaxique(j1,nbCarte, j2)) {
                carteJoué.clear();
                coutJoué.clear();
                décompose(s, this.j1, this.j2);
                if (!verifSyntaxique(j1, nbCarte, j2)) {
                    System.out.print("#> ");
                    s = sc.nextLine();
                }
            }
        }
    }

    public void lectureEntrerJ2()
    {
        Scanner sc = new Scanner(System.in);
        String s;
        int nbCarte = this.j2.nbDeCarteEnMain();

        System.out.print("> ");
        s = sc.nextLine();
        décompose(s, j2, j1);
        if (!verifSyntaxique(j2,nbCarte, j1)){
            carteJoué.clear();
            coutJoué.clear();
            while (!verifSyntaxique(j2,nbCarte, j1)) {
                carteJoué.clear();
                coutJoué.clear();
                décompose(s, this.j2, this.j1);
                if (!verifSyntaxique(j2, nbCarte, j1)) {
                    System.out.print("#> ");
                    s = sc.nextLine();
                }
            }
        }
    }

    private void décompose(String s, Joueur joueur, Joueur joueurAdv)
    {
        Scanner scs = new Scanner(s);
        boolean ascAdv = false, descAdv = false;

        while (scs.hasNext()) {

            String coup = scs.next();
            try {

                if (joueur.aCetteCarteEnMain(Integer.parseInt(coup.substring(0, 2), 10))) {

                    if (coup.charAt(2) == 'v') {

                        if (coup.length() > 3 && coup.charAt(3) == '\'' && !ascAdv) {
                            coutJoué.add(coup.substring(0, 4));
                            carteJoué.add(Integer.parseInt(coup.substring(0, 2), 10));
                            ascAdv = true;
                        }
                        else
                            coutJoué.add(coup.substring(0, 3));
                            carteJoué.add(Integer.parseInt(coup.substring(0, 2), 10));

                    } else if (coup.charAt(2) == '^') {

                        if (coup.length() > 3 && coup.charAt(3) == '\'' && !descAdv) {
                            coutJoué.add(coup.substring(0, 4));
                            carteJoué.add(Integer.parseInt(coup.substring(0, 2), 10));
                            descAdv = true;
                        }
                        else
                            coutJoué.add(coup.substring(0, 3));
                            carteJoué.add(Integer.parseInt(coup.substring(0, 2), 10));

                    }
                }

            } catch (NumberFormatException | StringIndexOutOfBoundsException ignored) { }
        }scs.close();
    }

    public boolean verifSyntaxique(Joueur joueur, int nbCarte, Joueur joueurAdv)
    {
        if (this.coutJoué.size() < 2){
            return false;
        }
        else {
            for (int cpt = 0; cpt < this.coutJoué.size(); ++cpt){
                String str = this.coutJoué.get(cpt);
                Integer cout = this.carteJoué.get(cpt);

                for (int cptRev = 1; cptRev < this.coutJoué.size(); ++cptRev) {
                    if ((cptRev < this.coutJoué.size() && (this.coutJoué.get(cptRev).equals(str)))) {
                        return false;
                    }
                    else if ((this.coutJoué.get(cptRev).contains("'")) && str.contains("'")) {
                        return false;
                    }
                }
            }
            return verifSemantique(joueur,nbCarte, joueurAdv);
        }
    }

    public boolean verifSemantique(Joueur joueur,int nbCarte, Joueur joueurAdv)
    {
        for (int cpt = 0; cpt < this.coutJoué.size(); ++cpt) {

            if (this.coutJoué.get(cpt).contains("v'") && (joueur.verifPoseCartePileDescAdv(joueurAdv, carteJoué.get(cpt))))
            {
                joueur.poseCartePileDescAdv(joueurAdv, carteJoué.get(cpt));
            }
            else if (this.coutJoué.get(cpt).contains("^'") && (joueur.verifPoseCartePileAscAdv(joueurAdv, carteJoué.get(cpt))))
            {
                joueur.poseCartePileAscAdv(joueurAdv, carteJoué.get(cpt));
            }
            else if (this.coutJoué.get(cpt).contains("^") && (joueur.verifposeCartePileAsc(carteJoué.get(cpt))))
            {
                joueur.poseCartePileAsc(carteJoué.get(cpt));
            }
            else if (this.coutJoué.get(cpt).contains("v") && (joueur.verifposeCartePileAsc(carteJoué.get(cpt))))
            {
                joueur.poseCartePileAsc(carteJoué.get(cpt));
            }
        }
        if (!(j1.nbDeCarteEnMain() <= nbCarte-2 || j1.nbDeCarteEnMain() == 0)){
            return false;
        }
        return true;
    }

    public void afficherInfoj1()
    {
        System.out.println(this.j1.afficherInfoJoueur());
        System.out.println(this.j2.afficherInfoJoueur());
        System.out.println(this.j1.afficherInfoMainJoueur());
    }

    public void afficherInfoj2()
    {
        System.out.println(this.j2.afficherInfoJoueur());
        System.out.println(this.j1.afficherInfoJoueur());
        System.out.println(this.j2.afficherInfoMainJoueur());
    }

    public void verifDefaite()
    {

    }

    public void verifVictoire()
    {

    }

}