package appli;

import java.util.ArrayList;
import static java.util.Collections.sort;

public class Main {

    private final ArrayList<Integer> main = new ArrayList<>();
    private final int nbCarteMax = 6;


    public Main(Cartes c)
    {
        for (;this.main.size() <= nbCarteMax-1;){
                this.main.add(c.piocherCarte());
            }
    }

    public void setMain(Integer carte)
    {
        assert (!(main.size() > nbCarteMax));

        this.main.add(carte);
    }

    public Integer getMain(int idx)
    {
        Integer pch = this.main.get(idx);
        this.main.remove(idx);
        return pch;
    }

    public int trvCarte(Integer carte)
    {
        return this.main.indexOf(carte);
    }

    public boolean carteExiste(Integer carte)
    {
        if (this.main.contains(carte))
        {
            return true;
        }
        return false;
    }

    public int getNbCarte()
    {
        return this.main.size();
    }

    public StringBuilder afficherMain()
    {
        trierMain();
        StringBuilder s = new StringBuilder("{ ");

        for(int i = 0; i < main.size(); ++i) {

            if (i == 0){
                s.append(String.format("%02d", this.main.get(i)));
            }
            else {
                s.append(" ").append(String.format("%02d", this.main.get(i)));
            }
        }
        return s.append(" }");
    }

    private void trierMain()
    {
        sort(main);
    }
}